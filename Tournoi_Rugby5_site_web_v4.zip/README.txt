Tournoi Rugby à 5 - version 4

Paramètres :
- 8 ou 10 équipes
- 1 ou 2 terrains pendant les matchs de poule
- phases finales sur 1 seul terrain
- matchs de 10 min + 2 min de rotation
- classement et phases finales dynamiques

Pour GitHub Pages, remplacez l'ancien index.html par ce nouveau fichier.
